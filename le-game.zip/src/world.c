#include "../include/world.h"
#include "../include/being.h"
#include "../include/game.h"
#include "../include/item.h"
#include <raylib.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

Texture2D particle_texture;

World world_new() {
  particle_texture = load_texture("res/assets/particle.png");
  return (World){
      .chunks = malloc(WORLD_LOADED_CHUNKS * sizeof(Chunk)),
      .chunks_amount = 0,
  };
}

void world_add_chunk(World *world, ChunkPos pos, Chunk chunk) {
  world->chunks[world->chunks_amount] = chunk;
  world->chunk_lookup.indices[world->chunks_amount] = world->chunks_amount;
  world->chunk_lookup.chunks_positions[world->chunks_amount] = pos;
  world->chunks_amount++;
}

ssize_t world_chunk_index_by_pos(const World *world, ChunkPos pos) {
  for (size_t i = 0; i < world->chunks_amount; i++) {
    if (vec2_eq(&world->chunk_lookup.chunks_positions[i], &pos)) {
      return world->chunk_lookup.indices[i];
    }
  }
  return -1;
}

bool world_has_chunk_at(const World *world, Vec2i chunk_pos) {
  ssize_t index = world_chunk_index_by_pos(world, chunk_pos);
  return index != -1;
}

void world_gen_chunk_at(World *world, Vec2i chunk_pos) {
  Chunk chunk;

  chunk_gen(&chunk, chunk_pos);

  world_add_chunk(world, chunk_pos, chunk);
}

TileInstance *world_ground_tile_at(World *world, TilePos tile_pos) {
  return world_tile_at(world, tile_pos, TILE_LAYER_GROUND);
}

TileInstance *world_highest_tile_at(World *world, TilePos tile_pos) {
  for (int l = TILE_LAYERS_AMOUNT - 1; l >= 0; l--) {
    TileInstance *tile = world_tile_at(world, tile_pos, l);
    TraceLog(LOG_INFO, "Loop Layer: %d", l);
    if (tile->type.id != TILE_EMPTY || l == 0) {
      TraceLog(LOG_DEBUG, "Tile: %s, tile on layer 1: %s", tile_type_to_string(&tile->type),
               tile_type_to_string(&world_tile_at(world, tile_pos, TILE_LAYER_TOP)->type));
      return tile;
    }
  }
  return &TILE_INSTANCE_EMPTY;
}

TileInstance *world_tile_at(World *world, TilePos tile_pos, TileLayer layer) {
  int chunk_tile_x = floor_mod(tile_pos.x, CHUNK_SIZE);
  int chunk_tile_y = floor_mod(tile_pos.y, CHUNK_SIZE);

  int chunk_x = floor_div(tile_pos.x, CHUNK_SIZE);
  int chunk_y = floor_div(tile_pos.y, CHUNK_SIZE);

  ChunkPos chunk_pos = vec2i(chunk_x, chunk_y);

  if (world_has_chunk_at(world, chunk_pos)) {
    Chunk *chunk = &world->chunks[world_chunk_index_by_pos(world, chunk_pos)];
    TileInstance *tile = &chunk->tiles[chunk_tile_y][chunk_tile_x][layer];
    return tile;
  }

  return &TILE_INSTANCE_EMPTY;
}

void world_gen(World *world) { world_gen_chunk_at(world, vec2i(0, 0)); }

bool world_set_tile(World *world, TilePos tile_pos, TileInstance tile) {
  return world_set_tile_on_layer(world, tile_pos, tile, tile.type.layer);
}

bool world_set_tile_on_layer(World *world, TilePos tile_pos, TileInstance tile, TileLayer layer) {
  int chunk_tile_x = floor_mod(tile_pos.x, CHUNK_SIZE);
  int chunk_tile_y = floor_mod(tile_pos.y, CHUNK_SIZE);
  int chunk_x = floor_div((tile_pos.x - chunk_tile_x), CHUNK_SIZE);
  int chunk_y = floor_div((tile_pos.y - chunk_tile_y), CHUNK_SIZE);
  ChunkPos chunk_pos = vec2i(chunk_x, chunk_y);
  if (world_has_chunk_at(world, chunk_pos)) {
    Chunk *chunk = &world->chunks[world_chunk_index_by_pos(world, chunk_pos)];
    bool success = chunk_set_tile(chunk, tile, chunk_tile_x, chunk_tile_y, layer);

    if (success) {
      for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
          int nx = chunk_tile_x + dx;
          int ny = chunk_tile_y + dy;
          TilePos pos = vec2i((chunk->chunk_pos.x * CHUNK_SIZE) + nx, (chunk->chunk_pos.y * CHUNK_SIZE) + ny);

          world_set_tile_texture_data(world, world_ground_tile_at(world, pos), pos.x, pos.y);
        }
      }

      for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
          int nx = chunk_tile_x + dx;
          int ny = chunk_tile_y + dy;
          TilePos pos = vec2i((chunk->chunk_pos.x * CHUNK_SIZE) + nx, (chunk->chunk_pos.y * CHUNK_SIZE) + ny);

          // Check bounds
          tile_calc_sprite_box(world_ground_tile_at(world, pos));
        }
      }
    }
    return success;
  }
  return false;
}

bool world_place_tile(World *world, TilePos tile_pos, TileInstance tile) {
  TileLayer layer = tile.type.layer;
  for (int l = layer - 1; l >= 0; l--) {
    if (world_tile_at(world, tile_pos, l)->type.id == TILE_EMPTY)
      return false;
    if (l == 0)
      break;
  }

  return world_set_tile_on_layer(world, tile_pos, tile, layer);
}

bool world_remove_tile(World *world, TilePos tile_pos) {
  TileInstance empty_instance = TILE_INSTANCE_EMPTY;
  empty_instance.box.x = tile_pos.x * TILE_SIZE;
  empty_instance.box.y = tile_pos.y * TILE_SIZE;
  TileInstance *tile = world_highest_tile_at(world, tile_pos);
  TraceLog(LOG_INFO, "Remove Layer: %d", tile->type.layer);
  Color color = tile->type.tile_color;
  ItemType *item_type = tile->type.tile_item;
  if (world_set_tile_on_layer(world, tile_pos, empty_instance, tile->type.layer)) {
    if (item_type != NULL) {
      TraceLog(LOG_DEBUG, "Drop item");
      world_add_being(world,
                      being_new(BEING_ITEM,
                                (BeingInstanceEx){.type = BEING_INSTANCE_ITEM,
                                                  .var = {.item_instance = {.item = {.type = *item_type}}}},
                                (tile_pos.x * TILE_SIZE) + GetRandomValue(-7, 9),
                                (tile_pos.y * TILE_SIZE) + GetRandomValue(-7, 9), 16, 16));
    }

    for (int i = 0; i < 5; i++) {
      ParticleInstance *particle =
          game_emit_particle(&GAME, tile_pos.x * TILE_SIZE + GetRandomValue(-9, 14),
                             tile_pos.y * TILE_SIZE + GetRandomValue(-9, 14), PARTICLE_TILE_BREAK,
                             (ParticleInstanceEx){.type = PARTICLE_INSTANCE_TILE_BREAK,
                                                  .var = {.tile_break = {.texture = particle_texture, .tint = color}}});
      particle->velocity = vec2f(0, 0);
      TraceLog(LOG_INFO, "r: %d g: %d b: %d a: %d", color.r, color.g, color.b, color.a);
    }
    return true;
  }
  return false;
}

void world_add_being(World *world, BeingInstance being) {
  if (world->beings_amount < MAX_ENTITIES_AMOUNT) {
    world->beings[world->beings_amount] = being;
    world->beings[world->beings_amount].being_instance_id = world->beings_amount;
    world->beings_amount++;
  }
}

void world_remove_being(World *world, BeingInstance *being) {
  for (int i = 0; i < world->beings_amount; i++) {
    if (world->beings[i].being_instance_id == being->being_instance_id) {
      // Shift everything after i left by one
      for (int j = i; j < world->beings_amount - 1; j++) {
        world->beings[j] = world->beings[j + 1];
      }
      world->beings_amount--;
      return;
    }
  }
}

void world_prepare_chunk_rendering(World *world, Chunk *chunk) {
  for (int y = 0; y < CHUNK_SIZE; y++) {
    for (int x = 0; x < CHUNK_SIZE; x++) {
      int chunk_x = chunk->chunk_pos.x * CHUNK_SIZE;
      int chunk_y = chunk->chunk_pos.y * CHUNK_SIZE;
      TilePos pos = vec2i(chunk_x + x, chunk_y + y);
      TileInstance *tile = world_ground_tile_at(world, vec2i(pos.x, pos.y));
      if (tile->type.id != TILE_EMPTY) {
        world_set_tile_texture_data(world, tile, pos.x, pos.y);
      }
    }
  }

  for (int y = 0; y < CHUNK_SIZE; y++) {
    for (int x = 0; x < CHUNK_SIZE; x++) {
      TilePos pos = vec2i((chunk->chunk_pos.x * CHUNK_SIZE) + x, (chunk->chunk_pos.y * CHUNK_SIZE) + y);
      TileInstance *tile = world_ground_tile_at(world, vec2i(pos.x, pos.y));
      if (tile->type.id != TILE_EMPTY) {
        tile_calc_sprite_box(tile);
      }
    }
  }
}

void world_set_tile_texture_data(World *world, TileInstance *tile, int x, int y) {
  TileTextureData *texture_data = &tile->texture_data;
  texture_data->surrounding_tiles[0] = world_ground_tile_at(world, vec2i(x - 1, y - 1))->type.id;
  texture_data->surrounding_tiles[1] = world_ground_tile_at(world, vec2i(x, y - 1))->type.id;
  texture_data->surrounding_tiles[2] = world_ground_tile_at(world, vec2i(x + 1, y - 1))->type.id;
  texture_data->surrounding_tiles[3] = world_ground_tile_at(world, vec2i(x - 1, y))->type.id;
  texture_data->surrounding_tiles[4] = world_ground_tile_at(world, vec2i(x + 1, y))->type.id;
  texture_data->surrounding_tiles[5] = world_ground_tile_at(world, vec2i(x - 1, y + 1))->type.id;
  texture_data->surrounding_tiles[6] = world_ground_tile_at(world, vec2i(x, y + 1))->type.id;
  texture_data->surrounding_tiles[7] = world_ground_tile_at(world, vec2i(x + 1, y + 1))->type.id;
}

void world_prepare_rendering(World *world) {
  for (int i = 0; i < world->chunks_amount; i++) {
    world_prepare_chunk_rendering(world, &world->chunks[i]);
  }
}

void world_render(World *world) {
  for (int i = 0; i < world->chunks_amount; i++) {
    Vec2i chunk_pos = world->chunk_lookup.chunks_positions[i];
    int chunk_x = chunk_pos.x * CHUNK_SIZE;
    int chunk_y = chunk_pos.y * CHUNK_SIZE;
    Chunk *chunk = &world->chunks[i];
    for (int y = chunk_y; y < chunk_y + CHUNK_SIZE; y++) {
      for (int x = chunk_x; x < chunk_x + CHUNK_SIZE; x++) {
        DrawTexture(tile_variants_by_index(chunk->variant_index, 0,
                                           0)[chunk->background_texture_variants[y - chunk_y][x - chunk_x]],
                    x * TILE_SIZE, y * TILE_SIZE, WHITE);
      }
    }
    for (int l = 0; l < TILE_LAYERS_AMOUNT; l++) {
      for (int y = 0; y < CHUNK_SIZE; y++) {
        for (int x = 0; x < CHUNK_SIZE; x++) {
          TileInstance *tile = &chunk->tiles[y][x][l];
          tile_render(tile);
        }
      }
    }
  }
}

void load_world(World *world, const DataMap *data) {
  uint8_t chunks = data_map_get(data, "len").var.data_byte;
  for (int i = 0; i < chunks; i++) {
    char key[2];
    snprintf(key, 2, "%u", i);
    Data data_map = data_map_get(data, key);
    DataMap map = data_map.var.data_map;
    Chunk chunk;
    chunk_load(&chunk, &map);
    world_add_chunk(world, chunk.chunk_pos, chunk);
  }
}

// TODO: Dealloc... pretty much everything
void save_world(const World *world, DataMap *data) {
  data_map_insert(data, "len", data_byte((uint8_t)world->chunks_amount));
  for (int i = 0; i < world->chunks_amount; i++) {
    DataMap map = data_map_new(300);
    const Chunk *chunk = &world->chunks[i];
    chunk_save(chunk, &map);
    char key[2];
    snprintf(key, 2, "%u", i);
    data_map_insert(data, key, data_map(map));
  }
}
