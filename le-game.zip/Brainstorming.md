Le-game story brainstorming
# Kommentar zur Story
- 1. Der Zwerg erwacht aus einem tiefen Schlaf und sieht die Welt um sich kaputt und verottet.
    - Die Idee mit dem tiefen Schlaf hatte ich auch und die is ziemlich gut, bloß glaub ich halt, dass das zusehr an zelda erinnert
    - Die welt sollte auf jeden fall den anschein haben, als ob sie bissl zerstört ist und halt richtig verlassen, aber ned verottet (also halt der artstyle/vibe den wir eh schon haben)
- 2. Er versucht die Welt zu restaurieren ☑️
    - Wir sollten halt bloß nicht dem Spieler aufzwingen, die Welt zu restaurieren, sondern ihm die immer noch Wahl lassen, ob er das wirklich will (Es is ja immernoch ein openworld sandbox spiel) (maybe könnte es auch ne alternative story geben, wenn der spieler die welt noch weiter zerstört… idk, is maybe bissl too much dann)
- 3. Er läuft nach dem „Erwachen“ rum und entdeckt dann immer mehr stuff und die Welt wird lebendiger, umso mehr er rumläuft ☑️
    - Wir müssen halt iwie dem Spieler erklären, dass er die Möglichkeit hat weiter herumzulaufen und dadurch neuen Stuff zu entdecken (obv kann er auch einfach auf der stelle stehen bleiben, aber er sollte zumindest wissen, dass die welt immer lebendiger wird, wenn er rumläuft)
- 4. Die Idee mit dem Vopadinger, der sich aus so körperteilen zusammensetzt, die der Spieler entdeckt is richtig cool, ich würde allerdings den Vopadinger und den Schattentypen zu zwei unterschiedlichen Figuren machen. (Mehr dazu im nächsten Teil)
# Vorschläge zu deinen Punkten
- 1. Der Spieler ist ganz am Anfang noch gar ned der Zwerg, sonder man fliegt am Anfang über die Map (keine pyhsische Gestalt, sonder halt einfach so der Spirit vom Spieler und der Bereich in dem man rumfliegen kann is begrenzt) und muss den Spieler suchen, der in ner Ruine (von ner Holzhütte oder nem Turm oder so) sitzt und ihn dann selecten, dadurch erwacht der Spieler zum Leben und man kann ihn ganz normal steuern
- 4. Der Vopadinger is so der main Gegner (wir sollten den maybe zu ner Frau machen), von dem man schon am Anfang weiß, dass er der Gegner ist. Die Enemies, die es im Spiel gibt sind halt dann einfach die Kinder des Vopadinga.
- 4. Der Schattenzwerg hat von Anfang an so ne Schattengestalt und beobachtet den Spieler immer wieder (halt so herobrine creepy pasta mäßig) (Dadurch kommt die Person, die das Game spielt maybe auf die Idee, dass diese Schattenfigur auch ein Kind des Vopadinga ist… um dann am Ende von der Story nochmal überrascht zu werden). Wie gesagt, wird es halt dann je länger man das Spiel spielt, immer klarer, dass der Schattenzwerg ne unabhängige Figur is. Ganz am Ende (von der Storyline, dass normale Game kann man ja unbegrenzt lange spielen) fightet man dann gegen den Vopadinga (Epic bossfight) und nachdem der besiegt ist, erfährt man erst mehr über den Schattenzwerg und dann halt das Ende, wo revealt wird, wer der Schattenzwerg wirklich ist (entweder halt die böse Seite des Maincharacters/ein Beschützer der jetzigen Welt/ein Beobachter).

# Eigene Ideen
- Der Zwerg kann sich laut der Lore noch teilweise an seine Vergangenheit erinnern und wird vom Gewissen geplagt (muss dem Spieler dann iwie kommuniziert werden)
- Iwann findet/baut der Zwerg ne Steampunk zeitmaschine, mit der man versucht in der Zeit zurückzureisen, um seine Fehler rückgängig zu machen (funktioniert nicht)

# Gameplay Ideen
- Inventar besteht nur aus 2 Slots (die beiden Handslots) + Armor Slots, am Anfang kriegt man außerdem nen Backpack, damit man ein bisschen Inventarspace hat, in dem Backpack is außerdem starter gear drinnen (ähnlich wie bei Terraria, damit man am Anfang keine Bäume oder so mit der Hand abbauen muss)
- Die Tiere sehen nich allzu inhuman aus, aber sie sind def auch keine normalen Tiere, sondern haben alle nen milden Fantasy-aspect (Schwein mit Hörnern, Kuh/Schaf -hybrid…)
- Die Enemies sind wie gesagt so mini Vopadinga mit dem/der Vopadinga als Chef*in
  
