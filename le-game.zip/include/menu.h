#pragma once

typedef enum {
    MENU_NONE,
    MENU_SAVE,
    MENU_START,
} MenuId;
