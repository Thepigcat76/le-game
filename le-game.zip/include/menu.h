#pragma once

typedef enum {
    MENU_NONE,
    MENU_SAVE,
    MENU_START,
    MENU_BACKPACK,
} MenuId;
