surtur build --win
mv ./build/cozy-wrath.exe ./
git add cozy-wrath.exe